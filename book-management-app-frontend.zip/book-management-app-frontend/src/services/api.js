import axios from 'axios';

const API_URL = 'http://localhost:7000'; // Update if necessary

export const login = async (credentials) => {
  try {
    const response = await axios.post(`${API_URL}/login`, credentials);
    return response.data;
  } catch (error) {
    console.error('Login error:', error);
    throw error;
  }
};
